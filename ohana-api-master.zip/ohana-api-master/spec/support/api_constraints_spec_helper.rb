def header_for_version(version)
  "application/vnd.ohanapi+json;version=#{version}"
end
