FactoryBot.define do
  factory :program do
    name { 'Collection of Services ' }
    alternate_name { ' Also Known As' }
    organization
  end
end
