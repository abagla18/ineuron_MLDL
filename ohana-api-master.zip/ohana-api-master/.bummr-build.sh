#!/bin/sh
bundle exec rspec --fail-fast
