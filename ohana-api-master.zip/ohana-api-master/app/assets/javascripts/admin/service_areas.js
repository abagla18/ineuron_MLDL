$(document).ready(function() {
  $('#service_service_areas').select2();
});
